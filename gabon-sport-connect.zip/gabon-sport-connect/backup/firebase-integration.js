/**
 * 📋 FIREBASE INTEGRATION MODULE
 * Système de gestion des documents professionnels
 * Gabon Sport Connect
 * 
 * Ce module gère :
 * - Sauvegarde/récupération des documents
 * - Gestion des exigences par rôle/discipline
 * - Audit logging
 * - Synchronisation admin
 */

// ═════════════════════════════════════════════════════════════
// FIREBASE CONFIG & INIT
// ═════════════════════════════════════════════════════════════

const firebaseConfig = {
  // À remplacer par votre configuration Firebase
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialiser Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const storage = firebase.storage();
const auth = firebase.auth();

// ═════════════════════════════════════════════════════════════
// CONFIGURATION COLLECTIONS
// ═════════════════════════════════════════════════════════════

/**
 * Initialiser les collections Firebase
 * À exécuter une seule fois lors de la première configuration
 */
async function initializeFirebaseStructure() {
  try {
    console.log('Initialisation de la structure Firebase...');

    // 1. Créer les exigences par défaut
    const defaultRequirements = {
      athlete_all: {
        role: 'athlete',
        discipline: 'all',
        documents: [
          {
            id: 'photo',
            name: 'Photo Professionnelle',
            description: '4x6 cm, fond blanc, visage clair',
            fileType: 'image',
            required: true,
            maxSize: 5242880, // 5MB
            acceptedFormats: ['image/jpeg', 'image/png']
          },
          {
            id: 'idcard',
            name: 'Carte d\'Identité',
            description: 'Copie recto-verso, lisible',
            fileType: 'image',
            required: true,
            maxSize: 5242880
          },
          {
            id: 'medical',
            name: 'Certificat Médical',
            description: 'Certifiant l\'aptitude physique',
            fileType: 'pdf',
            required: true,
            maxSize: 10485760 // 10MB
          }
        ],
        createdAt: new Date(),
        updatedAt: new Date()
      }
    };

    // Sauvegarde les exigences
    for (const [key, value] of Object.entries(defaultRequirements)) {
      await db.collection('admin_requirements').doc(key).set(value);
      console.log(`✓ Exigences créées : ${key}`);
    }

  } catch (error) {
    console.error('Erreur initialisation Firebase:', error);
  }
}

// ═════════════════════════════════════════════════════════════
// UPLOAD DE FICHIERS
// ═════════════════════════════════════════════════════════════

/**
 * Uploader un fichier vers Firebase Storage
 * @param {File} file - Fichier à uploader
 * @param {String} userId - ID utilisateur
 * @param {String} role - Rôle utilisateur
 * @param {String} requirementId - ID de l'exigence
 * @returns {Promise} - URL du fichier uploadé
 */
async function uploadFileToStorage(file, userId, role, requirementId) {
  return new Promise((resolve, reject) => {
    // Créer un chemin unique
    const timestamp = new Date().getTime();
    const fileName = `${timestamp}_${file.name}`;
    const storagePath = `documents/${userId}/${role}/${requirementId}/${fileName}`;
    
    const storageRef = storage.ref(storagePath);
    const uploadTask = storageRef.put(file);

    // Observer les changements d'upload
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        // Progression
        const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        console.log(`Upload progress: ${progress}%`);
        
        // Émettre un événement de progression
        window.dispatchEvent(new CustomEvent('uploadProgress', {
          detail: { progress, requirementId, fileName }
        }));
      },
      (error) => {
        // Erreur
        console.error('Erreur upload:', error);
        reject(error);
      },
      async () => {
        // Succès
        const downloadUrl = await uploadTask.snapshot.ref.getDownloadURL();
        console.log(`✓ Fichier uploadé: ${downloadUrl}`);
        resolve(downloadUrl);
      }
    );
  });
}

/**
 * Uploader plusieurs fichiers
 * @param {Array} files - Array de {file, requirementId}
 * @param {String} userId - ID utilisateur
 * @param {String} role - Rôle utilisateur
 * @returns {Promise} - Array d'URLs
 */
async function uploadFilesInBatch(files, userId, role) {
  const uploadPromises = files.map(({ file, requirementId }) =>
    uploadFileToStorage(file, userId, role, requirementId)
      .then(url => ({
        url,
        requirementId,
        fileName: file.name,
        fileSize: file.size,
        uploadedAt: new Date()
      }))
  );

  return Promise.all(uploadPromises);
}

// ═════════════════════════════════════════════════════════════
// SAUVEGARDE DES MÉTADONNÉES
// ═════════════════════════════════════════════════════════════

/**
 * Sauvegarder les métadonnées des documents uploadés
 * @param {String} userId - ID utilisateur
 * @param {Object} uploadData - Données d'upload
 * @returns {Promise}
 */
async function saveDocumentMetadata(userId, uploadData) {
  try {
    const documentRef = db.collection('document_uploads').doc(userId);

    // Calculer le pourcentage de complétion
    const completionData = calculateCompletion(userId, uploadData);

    // Préparer les données
    const documentData = {
      userId: userId,
      role: uploadData.role,
      discipline: uploadData.discipline,
      contractType: uploadData.contractType,
      clubId: uploadData.clubId || null,
      files: uploadData.files.map(f => ({
        id: f.id || generateId(),
        requirementId: f.requirementId,
        fileName: f.fileName,
        fileSize: f.fileSize,
        url: f.url,
        status: 'pending', // pending | approved | rejected
        uploadedAt: f.uploadedAt,
        expiresAt: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000), // 90 jours
        hash: generateFileHash(f), // Pour vérifier l'intégrité
        notes: ''
      })),
      status: 'incomplete', // incomplete | complete | under_review | approved | rejected
      completionPercentage: completionData.percentage,
      missingDocuments: completionData.missing,
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
      submittedAt: null,
      reviewedAt: null,
      reviewedBy: null
    };

    // Utiliser merge pour ne pas écraser les données existantes
    await documentRef.set(documentData, { merge: true });

    // Ajouter au journal d'audit
    await addAuditLog({
      action: 'document_upload',
      userId: userId,
      role: uploadData.role,
      discipline: uploadData.discipline,
      filesCount: uploadData.files.length,
      status: 'success'
    });

    return { success: true, data: documentData };

  } catch (error) {
    console.error('Erreur sauvegarde métadonnées:', error);
    await addAuditLog({
      action: 'document_upload',
      userId: userId,
      status: 'error',
      errorMessage: error.message
    });
    throw error;
  }
}

/**
 * Récupérer les documents d'un utilisateur
 * @param {String} userId - ID utilisateur
 * @returns {Promise} - Données des documents
 */
async function getUserDocuments(userId) {
  try {
    const docSnapshot = await db.collection('document_uploads').doc(userId).get();
    
    if (!docSnapshot.exists) {
      return null;
    }

    return docSnapshot.data();

  } catch (error) {
    console.error('Erreur récupération documents:', error);
    throw error;
  }
}

// ═════════════════════════════════════════════════════════════
// GESTION DES EXIGENCES
// ═════════════════════════════════════════════════════════════

/**
 * Charger les exigences pour un rôle/discipline
 * @param {String} role - Rôle utilisateur
 * @param {String} discipline - Discipline
 * @returns {Promise} - Array d'exigences
 */
async function getRequirements(role, discipline) {
  try {
    // Chercher d'abord les exigences spécifiques
    let query = db.collection('admin_requirements')
      .where('role', '==', role)
      .where('discipline', '==', discipline);

    let snapshot = await query.get();

    // Si pas trouvé, chercher les exigences générales
    if (snapshot.empty) {
      query = db.collection('admin_requirements')
        .where('role', '==', role)
        .where('discipline', '==', 'all');

      snapshot = await query.get();
    }

    if (!snapshot.empty) {
      return snapshot.docs[0].data().documents;
    }

    // Sinon retourner un array vide
    return [];

  } catch (error) {
    console.error('Erreur chargement exigences:', error);
    return [];
  }
}

/**
 * Ajouter une nouvelle exigence (admin only)
 * @param {Object} requirement - Objet exigence
 * @returns {Promise}
 */
async function addRequirement(requirement) {
  try {
    // Vérifier les permissions admin
    const user = auth.currentUser;
    if (!user) throw new Error('Non authentifié');

    const userRef = db.collection('admins').doc(user.uid);
    const adminDoc = await userRef.get();

    if (!adminDoc.exists || !adminDoc.data().isAdmin) {
      throw new Error('Permissions insuffisantes');
    }

    // Créer la clé du document
    const docKey = `${requirement.role}_${requirement.discipline}`;

    // Ajouter/mettre à jour
    const docRef = db.collection('admin_requirements').doc(docKey);
    const docSnapshot = await docRef.get();

    if (docSnapshot.exists) {
      // Ajouter à l'array existant
      await docRef.update({
        documents: firebase.firestore.FieldValue.arrayUnion({
          id: requirement.id,
          name: requirement.name,
          description: requirement.description,
          fileType: requirement.fileType,
          required: requirement.required,
          maxSize: requirement.maxSize,
          createdAt: new Date()
        }),
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    } else {
      // Créer un nouveau document
      await docRef.set({
        role: requirement.role,
        discipline: requirement.discipline,
        documents: [{
          id: requirement.id,
          name: requirement.name,
          description: requirement.description,
          fileType: requirement.fileType,
          required: requirement.required,
          maxSize: requirement.maxSize,
          createdAt: new Date()
        }],
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }

    await addAuditLog({
      action: 'requirement_added',
      userId: user.uid,
      role: requirement.role,
      requirement: requirement.id
    });

    return { success: true };

  } catch (error) {
    console.error('Erreur ajout exigence:', error);
    throw error;
  }
}

// ═════════════════════════════════════════════════════════════
// AUDIT & LOGGING
// ═════════════════════════════════════════════════════════════

/**
 * Ajouter une entrée au journal d'audit
 * @param {Object} logData - Données du log
 * @returns {Promise}
 */
async function addAuditLog(logData) {
  try {
    await db.collection('audit_logs').add({
      timestamp: firebase.firestore.FieldValue.serverTimestamp(),
      ...logData,
      userAgent: navigator.userAgent,
      ipAddress: await getClientIp()
    });
  } catch (error) {
    console.error('Erreur audit log:', error);
  }
}

/**
 * Récupérer les logs d'audit (admin only)
 * @param {Object} filters - Filtres {userId, action, startDate, endDate}
 * @returns {Promise} - Array de logs
 */
async function getAuditLogs(filters = {}) {
  try {
    const user = auth.currentUser;
    if (!user) throw new Error('Non authentifié');

    // Vérifier les permissions
    const adminDoc = await db.collection('admins').doc(user.uid).get();
    if (!adminDoc.exists || !adminDoc.data().isAdmin) {
      throw new Error('Permissions insuffisantes');
    }

    let query = db.collection('audit_logs');

    if (filters.userId) {
      query = query.where('userId', '==', filters.userId);
    }

    if (filters.action) {
      query = query.where('action', '==', filters.action);
    }

    if (filters.startDate) {
      query = query.where('timestamp', '>=', filters.startDate);
    }

    if (filters.endDate) {
      query = query.where('timestamp', '<=', filters.endDate);
    }

    const snapshot = await query.orderBy('timestamp', 'desc').limit(1000).get();

    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: doc.data().timestamp?.toDate()
    }));

  } catch (error) {
    console.error('Erreur lecture logs:', error);
    return [];
  }
}

// ═════════════════════════════════════════════════════════════
// STATISTIQUES & ANALYTICS
// ═════════════════════════════════════════════════════════════

/**
 * Obtenir les statistiques globales (admin only)
 * @returns {Promise} - Stats object
 */
async function getGlobalStats() {
  try {
    const user = auth.currentUser;
    if (!user) throw new Error('Non authentifié');

    const adminDoc = await db.collection('admins').doc(user.uid).get();
    if (!adminDoc.exists || !adminDoc.data().isAdmin) {
      throw new Error('Permissions insuffisantes');
    }

    // Nombre total de documents uploadés
    const allDocsSnapshot = await db.collection('document_uploads')
      .where('status', '!=', null)
      .get();

    const totalUsers = allDocsSnapshot.size;

    let totalFiles = 0;
    let completedProfiles = 0;
    let statsPerRole = {};
    let statsPerDiscipline = {};

    allDocsSnapshot.forEach(doc => {
      const data = doc.data();
      totalFiles += data.files ? data.files.length : 0;

      if (data.status === 'approved') {
        completedProfiles++;
      }

      // Stats par rôle
      statsPerRole[data.role] = (statsPerRole[data.role] || 0) + 1;

      // Stats par discipline
      statsPerDiscipline[data.discipline] = (statsPerDiscipline[data.discipline] || 0) + 1;
    });

    return {
      totalUsers,
      totalFiles,
      completedProfiles,
      pendingReview: totalUsers - completedProfiles,
      statsPerRole,
      statsPerDiscipline,
      generatedAt: new Date()
    };

  } catch (error) {
    console.error('Erreur stats globales:', error);
    throw error;
  }
}

/**
 * Obtenir les statistiques par discipline
 * @returns {Promise} - Stats par discipline
 */
async function getStatsByDiscipline() {
  try {
    const snapshot = await db.collection('document_uploads')
      .where('status', '==', 'approved')
      .get();

    const statsByDiscipline = {};

    snapshot.forEach(doc => {
      const discipline = doc.data().discipline;
      if (!statsByDiscipline[discipline]) {
        statsByDiscipline[discipline] = {
          total: 0,
          byRole: {}
        };
      }
      statsByDiscipline[discipline].total++;

      const role = doc.data().role;
      statsByDiscipline[discipline].byRole[role] = 
        (statsByDiscipline[discipline].byRole[role] || 0) + 1;
    });

    return statsByDiscipline;

  } catch (error) {
    console.error('Erreur stats discipline:', error);
    return {};
  }
}

// ═════════════════════════════════════════════════════════════
// UTILITAIRES
// ═════════════════════════════════════════════════════════════

/**
 * Calculer le pourcentage de complétion
 * @param {String} userId - ID utilisateur
 * @param {Object} uploadData - Données uploadées
 * @returns {Object} - {percentage, missing}
 */
async function calculateCompletion(userId, uploadData) {
  try {
    const requirements = await getRequirements(uploadData.role, uploadData.discipline);
    const requiredDocs = requirements.filter(r => r.required);
    
    const uploadedIds = uploadData.files.map(f => f.requirementId);
    const uploadedRequired = requiredDocs.filter(r => uploadedIds.includes(r.id));

    const percentage = Math.round((uploadedRequired.length / requiredDocs.length) * 100);
    const missing = requiredDocs.filter(r => !uploadedIds.includes(r.id));

    return {
      percentage,
      missing: missing.map(m => m.id)
    };

  } catch (error) {
    console.error('Erreur calcul complétion:', error);
    return { percentage: 0, missing: [] };
  }
}

/**
 * Générer un hash pour un fichier
 * @param {Object} file - Objet fichier
 * @returns {String} - Hash simple
 */
function generateFileHash(file) {
  return `${file.fileName}-${file.fileSize}-${file.uploadedAt}`;
}

/**
 * Générer un ID unique
 * @returns {String}
 */
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Obtenir l'IP du client (pour l'audit)
 * @returns {Promise<String>}
 */
async function getClientIp() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip;
  } catch (error) {
    return 'unknown';
  }
}

// ═════════════════════════════════════════════════════════════
// LISTENER EN TEMPS RÉEL
// ═════════════════════════════════════════════════════════════

/**
 * Écouter les changements en temps réel des documents d'un utilisateur
 * @param {String} userId - ID utilisateur
 * @param {Function} callback - Fonction de callback
 * @returns {Function} - Fonction pour arrêter l'écoute
 */
function listenToUserDocuments(userId, callback) {
  return db.collection('document_uploads').doc(userId)
    .onSnapshot(
      (docSnapshot) => {
        if (docSnapshot.exists) {
          callback({
            success: true,
            data: docSnapshot.data()
          });
        } else {
          callback({
            success: false,
            message: 'Aucun document trouvé'
          });
        }
      },
      (error) => {
        callback({
          success: false,
          error: error.message
        });
      }
    );
}

/**
 * Écouter les mises à jour d'exigences en temps réel
 * @param {String} role - Rôle
 * @param {String} discipline - Discipline
 * @param {Function} callback - Callback
 * @returns {Function} - Fonction pour arrêter l'écoute
 */
function listenToRequirements(role, discipline, callback) {
  const docKey = `${role}_${discipline}`;

  return db.collection('admin_requirements').doc(docKey)
    .onSnapshot(
      (docSnapshot) => {
        if (docSnapshot.exists) {
          callback({
            success: true,
            data: docSnapshot.data().documents
          });
        }
      },
      (error) => {
        callback({
          success: false,
          error: error.message
        });
      }
    );
}

// ═════════════════════════════════════════════════════════════
// EXPORTS
// ═════════════════════════════════════════════════════════════

// Rendre les fonctions disponibles globalement
window.firebaseDocuments = {
  // Fichiers
  uploadFileToStorage,
  uploadFilesInBatch,
  
  // Métadonnées
  saveDocumentMetadata,
  getUserDocuments,
  
  // Exigences
  getRequirements,
  addRequirement,
  
  // Audit
  addAuditLog,
  getAuditLogs,
  
  // Stats
  getGlobalStats,
  getStatsByDiscipline,
  
  // Listeners
  listenToUserDocuments,
  listenToRequirements,
  
  // Utilitaires
  calculateCompletion,
  initializeFirebaseStructure
};

console.log('✓ Module Firebase Documents chargé');
